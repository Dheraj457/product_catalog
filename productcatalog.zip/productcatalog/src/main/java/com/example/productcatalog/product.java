package com.example.productcatalog;

public class product {

}
